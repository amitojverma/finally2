package com.cts.bookShopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.AddToCart;
import com.cts.bookShopping.dao.AddToCartDAO;
import com.cts.bookShopping.dao.BooksDAO;
@Service("addToCartService")
@Transactional(propagation = Propagation.SUPPORTS)
public class AddToCartServiceImpl implements AddToCartService{

	@Autowired
	private AddToCartDAO addToCartDAO;

	public String addCartDetails(AddToCart add) {
		// TODO Auto-generated method stub
		return addToCartDAO.addCartDetails(add);
	}

	
	public List<AddToCart> viewCartDetails(String id) {
		// TODO Auto-generated method stub
		return addToCartDAO.viewCartDetails(id);
	}


	@Override
	public String deleteCartItem(int id) {
		// TODO Auto-generated method stub
		return addToCartDAO.deleteCartItem(id);
	}

}
