package com.cts.bookShopping.dao;

import com.cts.bookShopping.bean.userRegistration;

public interface RegisterationDAO {
	public String setUserDetails(userRegistration userregisteration);
}
