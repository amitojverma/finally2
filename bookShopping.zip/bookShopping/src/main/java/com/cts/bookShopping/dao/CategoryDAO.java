package com.cts.bookShopping.dao;

import java.util.List;

import com.cts.bookShopping.bean.Category;


public interface CategoryDAO {
	public List<Category> getCategoryName();
	public List<Category> getAllCategory();
	public String insertCategory(Category cat);
	public Category viewCategoryByName(String categoryName);
}
